package com.mv.Model;

import com.mv.Activity.ProgrammeManagmentActivity;
import com.mv.Activity.TemplatesActivity;

/**
 * Created by nanostuffs on 18-09-2017.
 */

public class ParentViewModel {
    TemplatesActivity templatesActivity;
    ProgrammeManagmentActivity programmeManagmentActivity;
}
